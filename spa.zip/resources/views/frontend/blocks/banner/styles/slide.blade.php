@if ($block)
    @php
        
        $title = $block->json_params->title->{$locale} ?? $block->title;
        $brief = $block->json_params->brief->{$locale} ?? $block->brief;
        $content = $block->json_params->content->{$locale} ?? $block->content;
        $image = $block->image != '' ? $block->image : null;
        $image_background = $block->image_background != '' ? $block->image_background : null;
        
        // Filter all blocks by parent_id
        $block_childs = $blocks->filter(function ($item, $key) use ($block) {
            return $item->parent_id == $block->id;
        });
    @endphp
    
    <div
    class="elementor-element elementor-element-8fd194a e-con-boxed e-con lazyloaded animated fadeIn"
    data-id="8fd194a"
    data-element_type="container"
    data-settings='{"animation":"fadeIn","background_background":"gradient","content_width":"boxed"}'
    data-e-bg-lazyload=""
  >
    <div class="e-con-inner">
      <div
        class="elementor-element elementor-element-1b86a4c e-con-full e-con"
        data-id="1b86a4c"
        data-element_type="container"
        data-settings='{"content_width":"full"}'
      >
        <div
          class="elementor-element elementor-element-d1088ef elementor-widget elementor-widget-heading"
          data-id="d1088ef"
          data-element_type="widget"
          data-widget_type="heading.default"
        >
          <div class="elementor-widget-container">
            <style>
              /*! elementor - v3.11.1 - 15-02-2023 */
              .elementor-heading-title {
                padding: 0;
                margin: 0;
                line-height: 1;
              }
              .elementor-widget-heading
                .elementor-heading-title[class*="elementor-size-"]
                > a {
                color: inherit;
                font-size: inherit;
                line-height: inherit;
              }
              .elementor-widget-heading
                .elementor-heading-title.elementor-size-small {
                font-size: 15px;
              }
              .elementor-widget-heading
                .elementor-heading-title.elementor-size-medium {
                font-size: 19px;
              }
              .elementor-widget-heading
                .elementor-heading-title.elementor-size-large {
                font-size: 29px;
              }
              .elementor-widget-heading
                .elementor-heading-title.elementor-size-xl {
                font-size: 39px;
              }
              .elementor-widget-heading
                .elementor-heading-title.elementor-size-xxl {
                font-size: 59px;
              }
            </style>
            <h1 class="elementor-heading-title elementor-size-default">
              {!!$content!!}
            </h1>
          </div>
        </div>
      </div>
      <div
        class="elementor-element elementor-element-1fcb01f elementor-widget-mobile__width-initial elementor-absolute elementor-widget elementor-widget-image"
        data-id="1fcb01f"
        data-element_type="widget"
        data-settings='{"_position":"absolute"}'
        data-widget_type="image.default"
      >
        <div class="elementor-widget-container">
          <img
            width="670"
            height="1024"
            src="url('{{$image}}')"
            class="attachment-large size-large wp-image-336"
            alt="GirlHero3 - Ariel Medical - Aesthetic Clinic | GREECE"
            decoding="async"
            loading="lazy"
            srcset="{{$image}}"
            sizes="(max-width: 670px) 100vw, 670px"
            title="Homepage 1 - Ariel Medical - Aesthetic Clinic | GREECE"
          />
        </div>
      </div>
    </div>
  </div>
@endif
