{{-- Khối này chỉ làm nhiệm vụ hiển thị nội dung section content
  Cho phép người dùng cấu hình linh động vị trí nội dung từng trang theo các khối block --}}
@yield('content')
