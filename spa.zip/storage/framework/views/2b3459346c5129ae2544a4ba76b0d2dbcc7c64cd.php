
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\spa\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>